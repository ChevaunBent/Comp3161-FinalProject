First install node js on your system
node.js

install the following packages using the command: npm i < package >
mysql
faker

using the following increase memory usage limit
node --max-old-space-size=4096 meal_system.js

In the meal_system.js file change the following to match your configuration

user: "root",
password: "root",
socketPath: "/Applications/MAMP/tmp/mysql/mysql.sock"

Then run: node meal_system.js

Done!
