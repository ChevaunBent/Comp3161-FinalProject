var mysql = require('mysql');
var faker = require('faker');

person_table_query = "CREATE TABLE person("
 +"person_id INT NOT NULL AUTO_INCREMENT,"
 +"first_name VARCHAR(30),"
 +"last_name VARCHAR(30),"
 +"age INT ,"
 +"height DECIMAL(10,2) ,"
 +"weight DECIMAL(10,2),"
 +"PRIMARY KEY (person_id))";

 inventory_table_query = "CREATE TABLE inventory ("
   +"inventory_id INT NOT NULL AUTO_INCREMENT,"
   +"PRIMARY KEY (inventory_id))";

 ingredient_table_query = "CREATE TABLE ingredient("
   +"ingred_id INT NOT NULL AUTO_INCREMENT,name VARCHAR(100),"
   +"category VARCHAR(30),calories DECIMAL(10,2),"
   +"PRIMARY KEY (ingred_id))";

 measurement_table_query = "CREATE TABLE measurement("
   +"base_unit VARCHAR(30) , abbreviation VARCHAR(7),"
   +"PRIMARY KEY(base_unit))";

// removed servings and calories : these are obtained from the recipe entity
 meal_table_query = "CREATE TABLE meal ("
    +"meal_id INT NOT NULL AUTO_INCREMENT,name VARCHAR(150),"
    +"PRIMARY KEY (meal_id))";

 type_table_query = "CREATE TABLE type("
   +"type_no INT NOT NULL AUTO_INCREMENT,meal_type VARCHAR(30),"
   +"PRIMARY KEY (type_no))";

 allergy_table_query = "CREATE TABLE allergy ("
   +"allergy_id INT NOT NULL AUTO_INCREMENT,name VARCHAR(30),"
   +"PRIMARY KEY (allergy_id))";

 nutrition_table_query = "CREATE TABLE nutrition ("
   +"nutrition_no INT NOT NULL AUTO_INCREMENT, calories DECIMAL(10,2),"
   +"total_fat DECIMAL(10,2),sugar DECIMAL(10,2),"
   +"sodium DECIMAL(10,2), protein DECIMAL(10,2),"
   +"saturated_fat DECIMAL(10,2),"
   +"PRIMARY KEY (nutrition_no))";


 recipe_table_query = "CREATE TABLE recipe ("
   +"recipe_id INT NOT NULL AUTO_INCREMENT,name VARCHAR(150),"
   +"serving INT,"
   +"nutrition_no INT,"
   +"PRIMARY KEY (recipe_id),"
   +"FOREIGN KEY (nutrition_no) REFERENCES nutrition(nutrition_no))";

 //note the attribute step was removed since dir_no can sub for it
 direction_table_query = "CREATE TABLE direction("
   +"recipe_id INT,dir_no INT,"
   +"detail VARCHAR(400), PRIMARY KEY (recipe_id , dir_no),"
   +"FOREIGN KEY (recipe_id) REFERENCES recipe(recipe_id) ON DELETE CASCADE)";

 image_table_query = "CREATE TABLE image ("
   +"meal_id INT,img_id INT,"
   +"title VARCHAR(30),escription VARCHAR(100),"
   +"date_taken DATE, PRIMARY KEY (meal_id , img_id),"
   +"FOREIGN KEY (meal_id) REFERENCES meal(meal_id) ON DELETE CASCADE)";


 own_table_query = "CREATE TABLE own("
   +"person_id INT ,inventory_id INT,"
   +"PRIMARY KEY (person_id, inventory_id),"
   +"FOREIGN KEY (inventory_id) REFERENCES inventory(inventory_id))";

 itemize_table_query = "CREATE TABLE itemize ("
    +"inventory_id INT,ingred_id  INT,"
    +"quantity INT,inStock VARCHAR(1),"
    +"expiration_date DATE,"
    +"PRIMARY KEY (inventory_id , ingred_id),"
    +"FOREIGN KEY (inventory_id) REFERENCES inventory(inventory_id),"
    +"FOREIGN KEY (ingred_id) REFERENCES ingredient(ingred_id))";

 make_table_query = "CREATE TABLE make ("
   +"person_id INT,recipe_id INT,"
   +"creation_date DATE,"
   +"PRIMARY KEY (person_id,recipe_id),"
   +"FOREIGN KEY (person_id) REFERENCES person(person_id),"
   +"FOREIGN KEY (recipe_id) REFERENCES recipe(recipe_id))";

 contains_table_query = "CREATE TABLE contain ("
   +"recipe_id INT,ingred_id INT,"
   +"base_unit VARCHAR(30),numeric_measure DECIMAL(10,2),"
   +"PRIMARY KEY (recipe_id , ingred_id, base_unit),"
   +"FOREIGN KEY (recipe_id) REFERENCES recipe(recipe_id),"
   +"FOREIGN KEY (ingred_id) REFERENCES ingredient(ingred_id),"
   +"FOREIGN KEY (base_unit) REFERENCES measurement(base_unit))";

 host_table_query = "CREATE TABLE host("
   +"person_id  INT,allergy_id INT,"
   +"PRIMARY KEY (person_id, allergy_id),"
   +"FOREIGN KEY (person_id) REFERENCES person(person_id),"
   +"FOREIGN KEY (allergy_id) REFERENCES allergy(allergy_id))";

 schedule_table_query = "CREATE TABLE schedule("
   +"person_id INT, meal_id INT,"
   +"type_no INT, meal_date DATE,"
   +"auto_gen VARCHAR(1),"
   +"PRIMARY KEY (person_id , meal_id, type_no),"
   +"FOREIGN KEY (person_id) REFERENCES person(person_id),"
   +"FOREIGN KEY (meal_id) REFERENCES meal(meal_id),"
   +"FOREIGN KEY (type_no) REFERENCES type(type_no))";

 prepare_table_query = "CREATE TABLE prepare("
   +"recipe_id INT,meal_id INT,"
   +"PRIMARY KEY (recipe_id, meal_id),"
   +"FOREIGN KEY (recipe_id) REFERENCES recipe(recipe_id),"
   +"FOREIGN KEY (meal_id) REFERENCES meal(meal_id))";

 reacts_table_query = "CREATE TABLE reacts ("
   +"allergy_id INT,ingred_id INT,"
   +"PRIMARY KEY (allergy_id, ingred_id),"
   +"FOREIGN KEY (allergy_id) REFERENCES allergy(allergy_id),"
   +"FOREIGN KEY (ingred_id) REFERENCES ingredient(ingred_id))";

var con = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "root",
  socketPath: "/Applications/MAMP/tmp/mysql/mysql.sock"
});

con.connect( function(err) {
  if (err) throw err;

  console.log("Connected!");


  con.query("DROP DATABASE IF EXISTS mealSystemDBS",function(err,result){
    if (err) throw err;
  });

  con.query("CREATE DATABASE mealSystemDBS",function(err,result){
    if (err) throw err;
    console.log("Database created");
  });


  con.query("USE mealSystemDBS",function(err,result){
    if (err) throw err;
    console.log("Using Database mealSystemDBS");
  });

  //create tables
  con.query(person_table_query, function (err, result){
    if (err) throw err;});
  con.query(inventory_table_query, function (err, result){
    if (err) throw err;});
  con.query(ingredient_table_query, function (err, result){
    if (err) throw err;});
  con.query(measurement_table_query, function (err, result){
    if (err) throw err;});
  con.query(meal_table_query, function (err, result){
    if (err) throw err;});
  con.query(type_table_query, function (err, result){
    if (err) throw err;});
  con.query(allergy_table_query, function (err, result){
    if (err) throw err;});
  con.query(nutrition_table_query, function (err, result){
    if (err) throw err;});
  con.query(recipe_table_query, function (err, result){
    if (err) throw err;});
  con.query(direction_table_query, function (err, result){
    if (err) throw err;});

  con.query(image_table_query, function (err, result){
    if (err) throw err;});
  con.query(own_table_query, function (err, result){
    if (err) throw err;});
  con.query(itemize_table_query, function (err, result){
    if (err) throw err;});
  con.query(make_table_query, function (err, result){
    if (err) throw err;});
  con.query(contains_table_query, function (err, result){
    if (err) throw err;});
  con.query(host_table_query, function (err, result){
    if (err) throw err;});
  con.query(schedule_table_query, function (err, result){
    if (err) throw err;});
  con.query(prepare_table_query, function (err, result){
    if (err) throw err;});
  con.query(reacts_table_query, function (err, result){
    if (err) throw err;});

  populate_person_own_inventory ();
  recipe_nutrition_instructions ();
  populate_meal_type ();
  populate_meals();
  populate_ingredients ();
  populate_measuremnt();
  populate_itemize ();
  populate_make ();
  contain();

  console.log("tables completed");

});

function populate_person_own_inventory( )
{
  faker.seed(300);
  let i ;
  //200,000 users
  for( i = 0 ; i < 200000 ; i++)
  {
      age = Math.floor(Math.random() * 70) + 18
      height = (Math.floor(Math.random() * 180) + 100) / 100 // measured in meters
      weight =(Math.floor(Math.random() * 10000) + 4500) / 100 // kg

      var _record = 'INSERT INTO person VALUES ( ' +
      '"'+ (i+1).toString() +'"' +' ,'+ '"'+faker.name.firstName()+'"'+','+
      '"'+faker.name.lastName()+'"'+','+'"'+age.toString()+'"'+','+'"'+height+'"'+','+
      '"'+ weight +'"'+ ')';

   // insert the person record
   con.query( _record , function (err, result){
     if (err) throw err;});

  //  console.log( i.toString() +" + 1 record inserted");

     // insert the inventory record for every user
     _record = 'INSERT INTO inventory VALUES ( )';

     con.query( _record , function (err, result){
       if (err) throw err;});

     _record = 'INSERT INTO own VALUES ("'+ (i+1).toString() +'","'+ (i+1).toString() +'")';
     con.query( _record , function (err, result){
       if (err) throw err;});}
}

/*  populating recipe, nutrition & directions table  below */

function recipe_nutrition_instructions ()
{
  faker.seed(300);
  let i = 0 ;

  food_suffix = [' Soup',' Stew', ' Roast' , ' Dried', ' Bake',' Jerk']

  //600,000 recipes
  for ( i = 0 ;  i < 600000 ; i++){

    //nutrition table
    nutrition_data = [0,0,0,0,0,0];
    nutrition_data[0] = Math.random()* 2000;
    nutrition_data[1] = Math.random()* 100 ;
    nutrition_data[2]  = Math.random()* 100;
    nutrition_data[3] = Math.random()* 100 ;
    nutrition_data[4] = Math.random()* 100 ;
    nutrition_data[5] = Math.random()* 100;

     _record = "INSERT INTO nutrition ( calories, total_fat , sugar , sodium , protein, saturated_fat) VALUES ("
    + nutrition_data[0]+ "," + nutrition_data[1] + "," + nutrition_data[2] + "," + nutrition_data[3]
    + "," + nutrition_data[4] + "," + nutrition_data[5] + ")";

    con.query( _record , function (err, result){
      if (err) throw err;});


    //recipe table name , serving , nutr_no
    n = Math.floor(Math.random() * 5)
    recipe_name = "";
    switch (n)
    {
      case 0 :
      recipe_name = faker.animal.fish() + " "+ food_suffix[n];
      break;
      case 1 :
      recipe_name = faker.animal.cow() + " "+ food_suffix[n];
      break;
      case 2 :
      recipe_name = faker.animal.bird() + " "+ food_suffix[n];
      break;
      case 3 :
      recipe_name = faker.animal.bear() + " "+ food_suffix[n];
      break;
      case 4 :
      recipe_name = faker.animal.crocodilia() + " "+ food_suffix[n];
      break;
    }
    _record = 'INSERT INTO recipe( name , serving , nutrition_no) VALUES ( "'+
    recipe_name + '",' + (n + 1).toString() + "," + (i+1).toString() + ")";


    con.query( _record , function (err, result){
      if (err) throw err;});

    // recipes steps

    for ( j = 0 ; j < (n+1) ; j++ ) {

       dir_no = j + 1 ;
      _record = "INSERT INTO direction ( recipe_id , dir_no , detail ) VALUES (" +
       (i+1).toString() + "," + dir_no.toString() + ",'" + faker.lorem.sentence() + "')";

      con.query( _record , function (err, result){
        if (err) throw err;});
    }

  }
}

async function  populate_meals ()
{
    // id , name
   //  create a meal  sampling 600 recipe to lighten the load on the hardware
  //   can increase the amount if you want but this will affect other tables
 //    so make changes where necessary

   let promise = new Promise ( (resolve , reject ) => {

           let i = 0 ;
           for ( i = 0 ; i < 600 ; i++)
           {

              select_query = "SELECT name FROM recipe WHERE recipe_id = " + "'" + (i + 1).toString() + "'";
              con.query( select_query , function (err, result, fields) {
              if (err) throw err;

                   result.forEach( (row) => {
                     _record = 'INSERT INTO meal (name) VALUES ( "'+ row.name +'")';
                     con.query( _record , function (err,  result)
                     {
                        if (err) throw err;
                        //console.log(result);
                     });
                  });
              });
            }
          resolve("Promise returned ");
        });

        let msg = await promise;
        console.log(msg);

        setTimeout(function(){

          //con.query( 'SELECT * FROM meal', function (err, result, fields ){
          //if (err) throw err;
          //console.log("Executing the results: ");
          //console.log(result);});
          populate_schedule_meals();
          populate_prepare ();
        }, 54000);


      //console.log("Thes schedule function was called ");

}

function populate_meal_type ()
{
  let no_loops_need = 1400000

  // 200,000 people each have a meal plan for a week
  // breakfast, lunch and dinner, since  week = 7 days
  // 200k * 7 = 1400000 or 4.2 million records

  for (i = 0 ; i < no_loops_need ; i ++)
  {
        //create meal_type
        _record = "INSERT INTO type (meal_type) VALUES ( 'BREAKFAST' )";
        con.query( _record , function (err, result){if (err) throw err;});
        _record = "INSERT INTO type (meal_type) VALUES ( 'LUNCH' )";
        con.query( _record , function (err, result){if (err) throw err;});
        _record = "INSERT INTO type (meal_type) VALUES ( 'DINNER' )";
        con.query( _record , function (err, result){if (err) throw err;});
  }

}

function populate_schedule_meals () {


  var breakfast = 1 ; lunch  = 2 ; dinner = 3;
  var date = "2021-03-";
  var queries = [];
  var random_meal = [];
  var random_day = [];

  for ( i = 0 ; i < 200000 ; i ++)
  {
    random_meal.push( Math.floor((Math.random() * 500) + 1));
    random_day.push(Math.floor((Math.random() * 24) + 1));
  }

  //each person has at least one meal schedule
   for (i = 0 ; i < 200000 ; i ++)
   {

     for( j = 0 ; j <  7 ; j++ )
     {
       queries.push ('INSERT INTO schedule VALUES ( "'+ (i+1).toString() +'","'
       + (random_meal[i]++ ).toString() + '","' + breakfast.toString() +
       '","' + date + (random_day[i] + j).toString() + '",'+ '"N")');

       queries.push( 'INSERT INTO schedule VALUES ( "'+ (i+1).toString() +'","'
        + (random_meal[i]++ ).toString() + '","' + lunch.toString() +
       '","' + date + (random_day[i] + j).toString() + '",'+ '"N")');

       queries.push ('INSERT INTO schedule VALUES ( "' + (i+1).toString()+ '","'
       + (random_meal[i]++ ).toString() + '","' + dinner.toString() +
       '","' + date + (random_day[i] + j).toString() + '",' + '"N")');

        breakfast = breakfast + 3 ; lunch = lunch + 3 ; dnner = dinner + 3 ;
     }
   }

   queries.forEach( (query) => {
     //console.log(query);
     con.query( query , function (err, result){if (err) throw err;});
   });

}
function populate_ingredients (){

  let vegetable = [
  "Acorn Squash" ,"Amaranth" ,"Anaheim Chile",
  "Arrowroot","Artichoke", "Arugula",
  "Asparagus","Baby Candy Cane Beets","Baby Oyster Mushrooms",
  "Banana Squash","Beets","Belgian Endive",
  "Bell Peppers","Bitter Melons","Black Radish",
  "Black Salsify","Bok Choy","Boniato",
  "Broccoflower","Carrot","Chanterelle Mushroom",
  "Chayote Squash","Cherry Tomato","Chinese Eggplant",
  "Dandelion Greens","Delicata Squash","Garlic",
  "Ginger Root","Green Onion","Shallots",
  "Shiitake Mushrooms","Snow Peas", "Sorrel",
  "Spinach" , "Sugar Snap Peas", "Tomato","Yam"];

  //milk
  for ( i = 0 ; i < 50 ; i++){
    product = faker.animal.cow() + " Milk";
    calories = Math.floor( (Math.random()* 50) + 40 );
    _record = 'INSERT INTO ingredient(name,category,calories) VALUES ( "' + product + '"'+
    ","+'"DAIRY"'+ ',' +calories.toString() + ')';
    con.query( _record , function (err, result){
      if (err) throw err;});
  }

  //eggs
  for ( i = 0 ; i < 50 ; i++){
    product = faker.animal.bird() + " Egg";
    calories = Math.floor( (Math.random()* 50) + 40 );
    _record = 'INSERT INTO ingredient(name,category,calories) VALUES ( "' + product + '"'+
    ","+'"PROTEIN"'+ ',' +calories.toString() + ')';
    con.query(_record , function (err, result){
      if (err) throw err;});
  }

  //meat
  for ( i = 0 ; i < 50 ; i++){

    n = Math.floor( (Math.random() * 5)  + 1);
    product ="";
    switch (n)
    {
      case 1 :
      product = faker.animal.cow() + " Meat";
      break;
      case 2 :
      product = faker.animal.bird() + " Meat";
      break;
      case 3 :
      product = faker.animal.bear() + " Meat";
      break;
      case 4 :
      product = faker.animal.crocodilia() + " Meat";
      break;
    }
    calories = Math.floor( (Math.random()* 50) + 40 );
    _record = 'INSERT INTO ingredient(name,category,calories) VALUES ( "' + product + '"'+
    ","+'"MEAT"'+ ',' +calories.toString() + ')';
    con.query(_record, function (err, result){
      if (err) throw err;});
  }
  //Seafood
  for( i = 0 ; i < 50 ; i++)
  {
    product = faker.animal.fish() ;
    calories = Math.floor( (Math.random()* 50) + 40 );

    _record = 'INSERT INTO ingredient(name,category,calories) VALUES ( "' + product + '"'+
    ","+'"SEAFOOD"'+ ',' +calories.toString() + ')';
    con.query(_record, function (err, result){
      if (err) throw err;});
  }
  //Vegetables

  for ( i = 0 ; i < vegetable.length; i ++){

    calories = Math.floor( (Math.random()* 50) + 40 );
    _record = 'INSERT INTO ingredient(name,category,calories) VALUES ( "' + vegetable[i] + '"'+
    ","+'"VEGETABLE"'+ ',' +calories.toString() + ')';
    con.query(_record , function (err, result){
      if (err) throw err;});
  }

}

function populate_measuremnt() {

  base = [ "", "Tablespoon" , "tsp" , "Ounce","Oz", "Cup","c",
  "Quart","qt","Gallon","gal","Pound","lb","Units","Units"];

  for( i = 1 ; i < 8 ; i++){

     pos_1 = 2 * i  - 1;
     pos_2 = 2 * i;

     //console.log(pos_1);
     //console.log(pos_2);

   _record = 'INSERT INTO measurement( base_unit , abbreviation) VALUES ("'+ base[pos_1] + '","'
    + base[pos_2] + '" )';
    con.query(_record , function (err, result){
      if (err) throw err;});
  }

}

function populate_itemize (){

  for (i = 1 ; i < 201 ; i++){

    no_items = Math.floor(Math.random()*50) + 50;
    ingred_id = Math.floor(Math.random()* 100) + 1;

    for( j = 0 ; j < no_items ; j++)
    {

       qty = Math.floor(Math.random()* 20) + 1;
       inStock  = ["","Y","N"] ;
       gamble = Math.floor(Math.random() * 2) + 1;
       ex_date = "2021-"+ (Math.floor(Math.random()*8) + 4 ).toString() + "-" +
       (Math.floor( (Math.random()*29) + 1)).toString();

       _record = 'INSERT INTO itemize VALUES (' + i.toString() + ',' + (ingred_id + j).toString()
       + ',' + qty.toString() + ',"' + inStock[gamble] + '","'+ ex_date + '")';

       con.query(_record , function (err, result){
         if (err) throw err;});
    }
  }
}

function populate_make (){

  let r_1 = 1 ;
  let r_2 = 2 ;
  let r_3 = 3 ;

      // each person gets 3 recipes assigned to them
      //
      for( i = 1 ; i < 200001 ; i ++)
      {
        _date = "2020-"+ (Math.floor(Math.random()*12) + 1 ).toString() + "-" +
        (Math.floor( (Math.random()*29) + 1)).toString();

        _record = 'INSERT INTO make VALUES (' + i.toString() + ',' + r_1.toString()
        + ',"' + _date +'")';
        con.query(_record , function (err, result){
          if (err) throw err;});
        _record = 'INSERT INTO make VALUES ('+ i.toString() + ',' + r_2.toString()
        + ',"' + _date +'")';
        con.query(_record , function (err, result){
          if (err) throw err;});
        _record = 'INSERT INTO make VALUES ('+ i.toString() + ',' + r_3.toString()
        + ',"' + _date +'")';
        con.query(_record , function (err, result){
          if (err) throw err;});

        r_1 = r_1 + 3 ;
        r_2 = r_2 + 3 ;
        r_2 = r_3 + 3 ;
    }
  }

function contain (){

  base = ["Tablespoon" ,"Ounce", "Cup", "Quart","Gallon","Pound","Units"];

  // each recipe has associated measurements

  for ( i = 1 ; i < 600001 ; i++)
  {
     no_ingredients = Math.floor( Math.random() * 5 ) + 3 ;
     ingred_id = Math.floor( Math.random() * 230 ) + 1;

     for ( j = 0 ; j < no_ingredients ; j ++){

          unit = Math.floor( Math.random() * 7 );
          numeric_measure = Math.floor( Math.random() * 8 ) + 1 ;

          _record = 'INSERT INTO contain VALUES (' + i.toString() +','+ (ingred_id + j).toString()
          +  ',"' + base[unit] + '",' + numeric_measure.toString() + ')';

          con.query(_record , function (err, result){
            if (err) throw err;});
     }
  }
}

function populate_prepare (){

  // since we only sampled 600 recipes for 600 meals
  for( i = 1 ; i < 601 ; i++ )
  {
    _record = 'INSERT INTO prepare VALUES (' + i.toString() + ',' + i.toString() + ')';
    con.query(_record , function (err, result){
      if (err) throw err;});
  }
}

 /*
    --------------------------------QUERIES----------------------------------------
   note that some values are random e.g. dates so inspect the database
   to see what matches since the records change each time the system runs
 */

/*

  Example_1 : To be a stored procedure

  Task : Generate a shopping list from meal plan for recipe_id :
  person_id : 200
  note: since the person is logged in the id is already available

  (1) create view schedule_recipes as
      select prepare.recipe_id from prepare inner join
      (select * from schedule where person_id = "200" and
      (meal_date between "2021-03-24" and "2021-03-30")) as t
      on t.meal_id = prepare.meal_id;

  note: all the ingredients in the recipes scheduled

  (2) create view  ingred_list as
      select ingred_id from contain where recipe_id in
      (select recipe_id from schedule_recipes);

  note: check which ingredients are available in the inventory and produce a list for the
  ingredients not available

  (4) create view user_inventory as select ingred_id , inStock from itemize where inventory_id in
      (select inventory_id from own where person_id = "200");

  (5) select ingredient.name from ingredient where ingred_id in (
      select ingred_id from ingred_list where not ingred_id in ( select ingred_id from
      user_inventory ) or ingred_id in (select ingred_id from user_inventory where inStock = "N" ));


   note: drop views to free space

   drop view schedule_recipes;
   drop view ingred_list;
   drop view user_inventory;

*/
/*
   Example_2 : View Meal Plan After Creation

   person_id : 200
   date_range: "2021-03-24" and "2021-03-30"

   (1)  create view week_schedule as
        select meal_id, meal_date, type_no from schedule where person_id ="200" and
        (meal_date between "2021-03-24" and "2021-03-30");

   (2)  create view week_schedule_no_name as
        select week_schedule.meal_id as meal_id ,
        type.meal_type as meal_type , week_schedule.meal_date  as meal_date from  week_schedule
        inner join type on week_schedule.type_no = type.type_no;

   (3)  select name , meal_type , meal_date from week_schedule_no_name inner join
        meal on week_schedule_no_name.meal_id = meal.meal_id ;

        drop view week_schedule;
        drop view week_schedule_no_name;

*/

/*
    Example_3 : Keep track of the calorie count for the planned meals

    person_id : 200
    date_range: "2021-03-24" and "2021-03-30"

    (1) create view week_schedule as
        select meal_id from schedule where person_id ="200" and
        (meal_date between "2021-03-24" and "2021-03-30");

    (2) create view schedule_recipes as
        select recipe_id from prepare where meal_id in
        (select meal_id from week_schedule);

    (3) select SUM(calories) as Total_Calories from nutrition
        where nutrition_no in ( select nutrition_no from recipe where
        recipe_id in (select recipe_id from schedule_recipes));

        drop view week_schedule;
        drop view schedule_recipes;
*/
/*
    Example_4 : Request the creation of meals based on specified calorie count




*/
